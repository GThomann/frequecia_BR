import sys
sys.path.insert(0, '')
sys.path.append('.')
sys.path.append('..')

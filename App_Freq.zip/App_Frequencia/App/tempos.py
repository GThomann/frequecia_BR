#######
# Calcula da diferenca entre entrada e saida
#
# Autor: GThomann
# 
# Ultima atualizacao: 10/10/2021 01:30
# 
#######

import re  # uso de expressoes regulares
from ajustes import AjusteHoras


# Manipula o texto de interesse e separa os horarios
def _get_time_text(lines):
    """recebe como parametro uma lista com as linhas de interesse
        e retorna uma lista de string dos horarios  de entrada e saida
        de cada linha
    """

    # cod_list = ['2040', '2021', '1041', '1125']
    time_list = list()

    lines_len = len(lines)
    for i in range(len(lines)):
        line = lines[i]  # para debug
        # procura apenas por linhas tenham o padrao: 'dddd' -> codigo de freq
        result = re.search(r'\d{4}', lines[i])
        if (result):
            if (lines[i][9] == ':'):
                inicio = lines[i][7:12]
                fim = lines[i][13:18]
            else:
                inicio = '00:00'
                fim = '12:00'

            # time_list.append((inicio, fim))
        else:
            print(f'Não encontrado tratamento para o dia {lines[i][0:7]}')
            # adiciona
            lines[i] = lines[i][:-1] + ' XXXX' + lines[i][-1]
            line = lines[i]  # para debug
            inicio = '00:00'
            fim = '12:00'
        time_list.append((inicio, fim))
    return time_list


# calculo de tempo
def _delta_time_str(time_tuple_list):
    """recebe como parametro uma lista de tuplas
        onde cada tupla deve estar no formato (inicio, fim)
        retorna uma lista de string para cada entrada
    """
    delta = list()
    for item in time_tuple_list:
        h_ini, m_ini = item[0].split(':')
        h_fim, m_fim = item[1].split(':')

        h_ini, m_ini = (int(h_ini), int(m_ini))
        h_fim, m_fim = (int(h_fim), int(m_fim))

        mins_ini = (h_ini * 60) + m_ini
        mins_fim = (h_fim * 60) + m_fim
        d_mins = mins_fim - mins_ini

        if (d_mins < 0):  # o horario final passou das 23:59
            d_mins += (24 * 60)

        d_h = d_mins // 60  # parte inteira
        d_m = d_mins % 60  # resto
        '''
        if(d_h < 0):
            d_h += 24
        if(d_m < 0):
            d_m += 60
        '''
        str_delta = f'{d_h:02d}:{d_m:02d}'
        # delta.append(str(d_h)+':'+str(d_m))
        delta.append(str_delta)
    return delta


def calc_banco(filename):
    """recebe como parametro o arquivo com relatorio final tratado
        com cada linha no formato:
        dia_mes dia_semana hora_inicio hora_fim cod_frequencia delta
        Adiciona ao final de cada linha o resumo dos calculos
        e ao final do arquivo os totais gerais
    """
    ajuste = AjusteHoras()

    # lista de codigos envolvendo banco de horas
    bco_dict = {'2040': ajuste.calc_bh_he, '1125': ajuste.comp_bh}

    # lista de codigos envolvendo HE
    he_dict = {'2021': ajuste.he_tt, '1041': ajuste.desc_sal, '1093': ajuste.desc_sal, '1042': ajuste.desc_sal}

    # lista de codigos sem impacto no salario
    cod_dict = {'XXXX': ' --> Sem tratamento',
                '1044': ' --> Interstício de 11 horas',
                '1015': ' --> Doação de sangue',
                '1019': ' --> Férias',
                '1063': ' --> Código eleitoral',
                '1067': ' --> Abono gerencial',
                '1068': ' --> Folga por permuta',
                '1082': ' --> Quarentena',
                '2006': ' --> Ajuste de horario',
                '2022': '--> Compensação por permuta'}

    # le o arquivo com os intervalos calculados
    with open(filename, 'r', encoding='utf8') as f:
        lines = f.readlines()
        f.close()
    text = ''
    # percorre as linhas, calcula o codigo e adiciona o resultado no final da linha
    for line in lines:
        text += line[:-1]  # inicio da linha
        delta = line[-6:-1]
        cod = line[-11:-7]
        if (cod in bco_dict):
            bh, he = bco_dict[cod](delta)
            text += f' --> Banco: {bh}; HE: {he}'
        elif (cod in he_dict):
            if (cod == '2021'):
                text += ' --> Troca de Turno: '
            elif (cod == '1041' or cod == '1093' or cod == '1042'):
                text += ' --> Desconto no salário: '

            he = he_dict[cod](delta)
            text += f'{he}'
        elif (cod in cod_dict):
            text += cod_dict[cod]
        else:
            print(f'Código {cod} não está previsto!')
            '''
            if(cod == '1044'):
                text += ' --> Interstício de 11 horas'
            elif(cod == '2006'):
                text += ' --> Ajuste de horario'
            elif(cod == '1019'):
                text += ' --> Férias'
            elif(cod == '1067'):
                text += ' --> Abono gerencial'
            else:
                print(f'Código {cod} não está previsto!')
            '''
        text += line[-1]

    # rodape do arquivo
    t_bh, t_he, t_hett, t_desc = ajuste.summarize()
    totais = f'\nSaldo no BH: {t_bh}\nTotal HE: {t_he}\nTotal HE TT: {t_hett}\n'
    totais += f'Total a descontar: {t_desc}'

    with open(filename, 'w', encoding='utf8') as f:
        line1 = ' Data  Início Fim  Cod  Delta \tResumo\n'
        f.write(line1)
        f.write(text)
        f.write(totais)
        f.close()


def balanco_tempos(filename):
    """recebe como parametro o arquivo com relatorio final
        com cada linha no formato:
        dia_mes dia_semana hora_inicio hora_fim cod_frequencia
        e adiciona ao final de cada linha a diferenca de tempo
    """
    with open(filename, 'r', encoding='utf8') as f:
        # le todas as linhas do arquivo
        lines = f.readlines()
        f.close()

    lines_len = len(lines)
    time_list = _get_time_text(lines)
    time_lst_len = len(time_list)
    delta = _delta_time_str(time_list)

    # percorre todas as linhas do arquivo e adiciona o intervalo calculado
    text = ''
    lines_len = len(lines)
    delta_len = len(delta)
    for i in range(len(lines)):
        text += lines[i][:-1] + ' ' + delta[i] + '\n'

    with open(filename, 'w', encoding='utf8') as f:
        f.write(text)
        f.close()

#######
# Faz o Scrap do relatorio de frequencia e calcula as horas
#
# Autor: GThomann
# 
# Ultima atualizacao: 09/07/2020 03:00
# 
#######

import os, sys
from time import sleep, localtime
import tempos
import relatorio
from web_freq import RFCrawler

#sys.path.append('.')
__VERSION = "2.0"

def _start_digging(ano, crawler):
    '''comeca a busca dos dados na pagina web.
        recebe como parametro o ano para a busca
        retorna o nome do arquivo gerado com os dados brutos
    '''

    sap_url = "http://portalsap.petrobras.com.br"
    mes_atual = localtime().tm_mon
    mes_ano = 0
    valido = False
    while(not valido):
        mes = input("Digite o número do mês (01~12): ")
        if(mes.isdigit()):
            mes = int(mes)
            if(mes in range(1, mes_atual)):
                mes_ano = f'{mes:02d}/{ano}'
                valido = True
            else:
                print(f'Entrada inválida!\nDigite apenas números entre 1 e {mes_atual}.')
        else:
            print('Entrada inválida!\nDigite apenas números.')

    filename = f'Rel_{mes}-{ano}.txt'

    try:
        web_txt = crawler.get_web_data(sap_url, mes_ano)  #lista com o texto da area de interesse
        relatorio.create_file(web_txt, filename)
    except Exception as err:
        print(f'Erro ao processar a instrução: {err}')
        print(f'\nURL: {crawler.driver.current_url}')
        err_txt = f'main_resumo.py - line 47: try-except -> web_txt\n'
        err_txt += f'Erro ao processar a instrução: {err}'
        err_txt += f'\nURL: {crawler.driver.current_url}'
        relatorio.error_log('error_log.txt', err_txt)
    #finally:
        #crawler.quit_web_driver()
        
    return filename

def _end_data_processing(filename):
    '''recebe o nome do arquivo com os dados brutos
        trata os dados e atualiza o arquivo
    '''
    tempos.balanco_tempos(filename)
    tempos.calc_banco(filename)

def app_credit():
    _ = os.system('cls')  #limpa a tela no windows
    #icon = 'Icon made by Flat Icons from www.flaticon.com'
    #print('\nÍcone:\n')
    #print(icon)
    print('\nCriado por: Thomann\n')
    print('\nData: 04/2020\n')
    print(f'Versão: {__VERSION}')
    sleep(2)
    _ = os.system('cls')  #limpa a tela no windows
    
def _end_app():
    from pathlib import Path
    log_file = list(Path('.').glob('*.log'))
    for item in log_file :
        if(Path('.').joinpath(item).exists()):
            Path('.').joinpath(item).unlink()

def menu():
    opc = {1:'1 - Obter resumo do relatorio de frequencia', 2:'2 - Sair', 3:'3 - Créditos'}
    ano_atual = localtime().tm_year
    
    home_url = "http://portalpetrobras.petrobras.com.br"
    #sap_url = "http://portalsap.petrobras.com.br"
    try:
        crawler = RFCrawler(home_url)
    except Exception as err:
        print(f'Erro ao processar a instrução: {err}')
        print(f'\nURL: {crawler.driver.current_url}')
        err_txt = f'main_resumo.py - line 24: try-except -> crawler\n'
        err_txt += f'Erro ao processar a instrução: {err}'
        err_txt += f'\nURL: {home_url}'
        relatorio.error_log('error_log.txt', err_txt)
        
    loop = True
    while(loop):
        print('\n\nOpções disponíveis:\n')
        for op in opc:
            print(f'\t{opc.get(op)}')

        choice = input("\nDigite a sua opção: ")
        if(choice == '1'):
            #choice = int(choice)
            '''
            valido = False
            while(not valido):
                ano = input("\nDigite o ano: ")
                if(ano.isdigit()):
                    ano = int(ano)
                    #TODO: ajustar calculo do tempo e cod freq para data anterior a 2020
                    if((ano<=ano_atual) and (ano>=2020)):
                        filename = _start_digging(ano, crawler)  #comeca a captura de dados e gera o arquivo .txt inicial
                        valido = True
                    else:
                        #print(f'O ano deve estar entre {ano_atual-5} e {ano_atual}')
                        print(f'O ano deve ser maior ou igual a 2020 e menor ou igual a {ano_atual}')
                else:
                    print(f'Apenas números são aceitos!')
            '''
            filename = _start_digging(ano_atual, crawler)  #comeca a captura de dados e gera o arquivo .txt inicial
            _end_data_processing(filename)
            print('\nRelatório gerado com sucesso!')
            
        elif(choice == '2'):
            #choice = int(choice)
            print('\nTerminando a aplicação...')
            crawler.quit_web_driver()
            sleep(2)
            _end_app()
            loop = False
            
        elif(choice == '3'):
            #choice = int(choice)
            app_credit()
        else:
            print('\n\tOpção inválida.\n\t Tente novamente!\n')
            sleep(2)
            _ = os.system('cls')  #limpa a tela no windows
                  

if(__name__ == '__main__'):
    menu()

﻿#######
# Web Scrap do relatorio de frequencia
#
# Autor: GThomann
# 
# Ultima atualizacao: 10/10/2021 01:30
# 
#######

import sys
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from time import sleep


class RFCrawler():
    def __init__(self, start_url):
        # self.url = start_url
        self.driver = self.start_web_driver(start_url)

    def start_web_driver(self, url):
        '''Inicia um navegador web com o endereco inicial
        '''
        # opcoes do webdriver
        options = webdriver.FirefoxOptions()
        options.add_argument('-headless')  # sem renderizar o browser
        # driver para a janela principal usando o firefox
        driver = webdriver.Firefox(executable_path=r'.\WebDriver\geckodriver.exe', options=options)
        driver.implicitly_wait(15)  # espera de ate 15s
        sleep(1)

        return driver

    def quit_web_driver(self):
        # fecha a janela ativa do navegador
        self.driver.close()
        sleep(1)
        # troca para a janela restante
        # self.driver.switch_to.window(self.driver.window_handles[0])
        # fecha o navegador - pode ter so essa linha
        self.driver.quit()

    def get_web_data(self, sap_url, mes_ano):
        '''Acessa a pagina web da frequencia e obtem as
            informacoes relevantes
            retorna uma lista com o texto
        '''
        wait = WebDriverWait(self.driver, 20, poll_frequency=1)  # aguarda ate 20s o carregamento das paginas

        curr_page = self.driver.current_window_handle  # pagina atual
        print(f'Iniciando em:\n{self.driver.current_url}')
        # print(self.driver.current_url)

        self.driver.get(sap_url)
        sleep(3)

        title = 'Portal de Aplicações SAP'
        loaded = wait.until(EC.title_is(title))
        if (loaded):
            print('Página SAP carregada')

        print(f'\nSolicitando acesso em:\n {self.driver.current_url}')
        # print(self.driver.current_url)

        # aguarda 7s e mostra na interface o progresso
        for i in range(8):
            print('.', end=' ')
            sys.stdout.flush()  # libera o buffer (instrucao do print) no terminal
            sleep(1)

        # acessa o link da pagina do relatorio de frequencia no portal SAP
        status_sap = wait.until(
            EC.text_to_be_present_in_element((By.XPATH, '//*[@id="cat-appe-app-rlfr"]'), "Relatório de Frequência"),
            'SAP pg not loaded - 20s')
        sleep(2)
        if (status_sap):
            elem_rel_freq = wait.until(EC.element_to_be_clickable((By.XPATH, '//*[@id="cat-appe-app-rlfr"]')),
                                       'Link to Freq. not found - 20s')
            # elem_rel_freq = self.driver.find_element_by_xpath('//*[@id="cat-appe-app-rlfr"]')
            elem_rel_freq.click()
            print('\nAcesso permitido.')
        else:
            print('\nErro ao obter acesso.')
            return 'Unable to load RF page'
        # sleep(8)
        # captura as janelas abertas
        windows = self.driver.window_handles

        print(f'Janelas ativas: {len(windows)}')
        for handle in windows:
            if (not curr_page == handle):
                # muda para a nova aba/janela
                self.driver.switch_to.window(handle)
                curr_page = self.driver.current_window_handle

        # captura o botao para gerar o relatorio
        status_btn = wait.until(EC.text_to_be_present_in_element((By.CLASS_NAME, 'btn-action'), "Gerar Relatório"),
                                'RF pg not loaded - 20s')
        if (status_btn):

            # informacao ao usuario
            print(f'Gerando relatório, aguarde', end=' ')
            for i in range(5):  # aguarda 4s e mostra na interface o progresso
                print('.', end=' ')
                sys.stdout.flush()  # libera o buffer (instrucao do print) no terminal
                sleep(1)

            # if(status_btn):
            # btn_gerador = self.driver.find_element_by_class_name('btn-action')
            elem_btn_gerador = wait.until(EC.element_to_be_clickable((By.CLASS_NAME, 'btn-action')),
                                          'generate button not found -> 20s')
            # captura o campo de datas
            dataform = self.driver.find_element_by_xpath('//*[@id="mesAnoFilter"]')
            # elem_dataform = wait.until(EC.element_to_be_clickable((By.XPATH, '//*[@id="mesAnoFilter"]')))

            # limpa o campo
            dataform.clear()
            # elem_dataform.clear()

            # preenche com a data desejada
            dataform.send_keys(mes_ano)
            # elem_dataform.send_keys(mes_ano)

            # gera o novo relatorio
            # btn_gerador.click()  #gera o novo relatorio
            elem_btn_gerador.click()  # gera o novo relatorio

            sleep(6)  # aguarda a pagina ser carregada

        print('\nCarregando relatório de frequência...')
        tables_loaded = wait.until(
            EC.text_to_be_present_in_element((By.XPATH, '/html/body/div[2]/div[7]/div/div/div[1]'), "Ajustes"),
            'Tables not found - 20s')

        if (tables_loaded):
            print('Obtendo ajustes de frequência...')

            sleep(6)  # aguarda a pagina ser carregada
            # localiza todas as tabelas do relatorio
            tables = self.driver.find_elements_by_tag_name('table')
            ajustes = tables[2]  # terceira tabela -> ajustes

            # seleciona o corpo da tabela
            tab_ajustes = ajustes.find_element_by_tag_name('tbody')
            # seleciona as linhas da tabela
            linhas_ajustes = tab_ajustes.find_elements_by_tag_name('tr')

            # captura o texto de cada linha
            text = list()
            for linha in linhas_ajustes:
                text.append(linha.text)

        return text

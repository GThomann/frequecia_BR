#######
# Calcula banco de horas e HE
#
# Autor: GThomann
# 
# Ultima atualizacao: 01/04/2020 15:00
# 
#######

class AjusteHoras():
    

    def __init__(self):
        self.bh_pos = 0
        self.bh_neg = 0
        self.tot_he = 0
        self.tot_hett = 0
        self.tot_desc = 0
        
    def _str_to_min(self, tempo):
        '''recebe uma string no formato hh:mm e retorna
            a quantidade em minutos
        '''
        #converte string hh:mm em inteiro minutos
        h_temp, m_temp = tempo.split(':')
        h_temp, m_temp = int(h_temp), int(m_temp)
        minutos = (h_temp*60) + m_temp
        return minutos

    def _min_to_str(self, minutos):
        '''recebe a quantidade em minutos e retorna
            uma string no formato hh:mm
        '''
        hh = minutos//60  #parte inteira
        mm = minutos%60  #resto da divisao
        tempo = f'{hh:02d}:{mm:02d}'
        return tempo

    def summarize(self):
        '''retorna os totais dos calculos de HE e BH
            no formato de string hh:mm
        '''
        
        saldo_bh = self._min_to_str(self.bh_pos-self.bh_neg)
        tot_he = self._min_to_str(self.tot_he)
        tot_hett = self._min_to_str(self.tot_hett)
        tot_desc = self._min_to_str(self.tot_desc)

        return (saldo_bh, tot_he, tot_hett, tot_desc)

    def get_bh(self):
        '''retorna os totais dos bancos positivos e negativos
            no formato de string hh:mm
        '''
        bh_pos = self._min_to_str(self.bh_pos)
        bh_neg = self._min_to_str(self.bh_neg)
        return (bh_pos, bh_neg)

    def calc_bh_he(self, delta_str):
        '''recebe uma string de intervalo no formato hh:mm
            e retorna a qdt de minutos a serem inseridas no BH
            e a quantidade que sera hora extra
        '''
        delta = self._str_to_min(delta_str)
        bh = 0
        he = 0
        #ate duas horas, tudo para banco
        if(delta <= 120):
            bh += delta
        #acima de duas horas duas horas + 1/2 do excedente para banco
        # e 1/2 do excedente para he
        else:
            delta -= 120  #calcula o excedente
            bh_temp = delta//2  #calcula metade do excedente - divisao inteira
            bh += 120 + bh_temp
            he += delta - bh_temp  #calcula a qdt de he

        #adiciona os resultados na contagem geral
        self.bh_pos += bh
        self.tot_he += he

        #converte para string e retorna
        bh = self._min_to_str(bh)
        he = self._min_to_str(he)
        
        return (bh, he)
                
    def comp_bh(self, delta_str):
        '''recebe uma string de intervalo no formato hh:mm
            e retorna a qdt de minutos a serem abatidas no BH
        '''
        delta = self._str_to_min(delta_str)
        self.bh_neg += delta
        he = 0

        #converte para string e retorna
        bh = '-'+self._min_to_str(delta)
        he = self._min_to_str(he)
        
        return (bh, he)

    def he_tt(self, delta_str):
        '''recebe uma string de intervalo no formato hh:mm
            e retorna a qdt de minutos de troca de turno
        '''
        delta = self._str_to_min(delta_str)
        self.tot_hett += delta

        delta = self._min_to_str(delta)

        return delta

    def desc_sal(self, delta_str):
        '''recebe uma string de intervalo no formato hh:mm
            e retorna a qdt de minutos de desconto no salario
        '''
        delta = self._str_to_min(delta_str)
        self.tot_desc += delta

        delta = self._min_to_str(delta)

        return delta


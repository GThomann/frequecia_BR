#######
# Gera um arquivo .txt com as informacoes relevantes
#
# Autor: GThomann
# 
# Ultima atualizacao: 01/04/2020 16:00
# 
#######

import re  #uso de expressoes regulares

#Manipula o texto de interesse
def _format_text(text):
    '''recebe uma lista com as linhas de texto e retorna
        o texto formatado e alinhado
    '''

    final_text = list()

    lines = text[:]  # faz a copia da lista
    for i in range(len(lines)):
        #procura apenas por linhas tenham o padrao: 'dd ccc'
        #result = re.search('\d{2}\s[a-z]{3}', lines[i])
        
        #procura apenas por linhas tenham o padrao: ' ccc'
        #result = re.search('\s[a-z]{3}', lines[i])
        #procura apenas por linhas tenham o padrao: 'dd c?c' incluindo char unicode
        result = re.search('\d{2}\s[a-z].[a-z]', lines[i])

        _line = lines[i]
        if(not result):
            data = lines[i-1][0:7]  #inicio da linha com o dia do mes
            _line = data + lines[i]
            
        # remove o (+) e (-)
        _line = re. sub(r'[\(\)\+\-\*]','', _line)
        #remove o espaco duplo
        _line = re.sub('\s{2}', ' ',_line)
        
        #adiciona espacos para ajustar alinhamento
        if(not _line[9] == ':'):
            temp = _line[:7]+'-- -- -- -- '+_line[7:]
            _line = temp

        #remove o final da linha - apos o codigo da frequencia
        #faz a divisao apos o primeiro encontro de uma letra maiuscula apos um espaco
        _line = re.split('\s[A-Z]', _line, 1)[0]+'\n'
        #adiciona a linha tratada em uma nova lista
        final_text.append(_line)
    '''
    #a origem eh um arquivo txt
    with open(text, 'r', encoding='utf8') as f:
        # le todas as linhas do arquivo
        lines = f.readlines()
        
        #percorre todas as linhas do arquivo
        for i in range(len(lines)):
            #procura apenas por linhas tenham o padrao: 'dd ccc'
            result = re.search('\d{2}\s[a-z]{3}', lines[i])

            if(not result):
                data = lines[i-1][0:7]  #inicio da linha com o dia do mes
                lines[i] = data + lines[i]
                
            # remove o (+) e (-)
            lines[i] = re. sub(r'[\(\)+-]','', lines[i])
            #remove o espaco duplo
            lines[i] = re.sub('\s{2}', ' ',lines[i])
            
            #adiciona a linha tratada em uma nova lista
            final_text.append(lines[i])
    '''
    return final_text


def _save_txt_data(text, file_name):
    '''recebe um texto no formato final e o nome de um arquivo
        e escreve o texto no arquivo
    '''
    
    #abre um novo arquivo de texto para o texto tratado
    with open(file_name, 'w', encoding='utf8') as out:

        #escreve todas as linhas da lista no arquivo
        out.writelines(text)
        out.close()
        
def add_line_end(raw_web_text):
    #adiciona a quebra de linha ao final da linha obtida da web
    raw_text = list()
    for line in raw_web_text:
        line = line+'\n'
        raw_text.append(line)

    return raw_text


def create_file(raw_web_text, out_filename):
    '''recebe uma lista com o texto de interesse
        e gera um arquivo .txt com os dados formatados
    '''
    #adiciona a quebra de linha ao final da linha obtida da web
    raw_text = add_line_end(raw_web_text)
        
    final_text = _format_text(raw_text)
    _save_txt_data(final_text, out_filename)
    
def error_log(error_file, message):
    '''recebe um texto de erro e o nome de um arquivo
        e escreve o texto no arquivo
    '''
    
    #abre um novo arquivo de texto para o texto tratado
    with open(error_file, 'a', encoding='utf8') as out:

        #escreve todas as linhas da lista no arquivo
        out.write(message)
        out.close()
